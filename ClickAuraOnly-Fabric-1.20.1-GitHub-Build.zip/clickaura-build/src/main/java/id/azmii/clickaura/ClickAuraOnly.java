package id.azmii.clickaura;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class ClickAuraOnly implements ClientModInitializer {
    private static final double RANGE = 5.0;
    private static final double RANGE_SQUARED = RANGE * RANGE;
    private static final double FOV_DEGREES = 360.0;

    private static KeyBinding toggleKey;
    private static boolean enabled;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.clickaura_only.toggle",
            GLFW.GLFW_KEY_Z,
            "category.clickaura_only"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("ClickAura: " + (enabled ? "ON" : "OFF")), true);
                }
            }

            if (!enabled || client.player == null || client.world == null
                || client.interactionManager == null || client.currentScreen != null) {
                return;
            }

            // Match Wurst ClickAura's activation: the player must hold the attack button.
            if (!client.options.attackKey.isPressed()) {
                return;
            }

            // Respect Minecraft's normal attack cooldown instead of sending attacks every tick.
            if (client.player.getAttackCooldownProgress(0.5F) < 1.0F) {
                return;
            }

            LivingEntity target = findTarget(client);
            if (target != null) {
                client.interactionManager.attackEntity(client.player, target);
                client.player.swingHand(Hand.MAIN_HAND);
            }
        });
    }

    private static LivingEntity findTarget(MinecraftClient client) {
        PlayerEntity player = client.player;
        Vec3d eyePos = player.getCameraPosVec(1.0F);
        Vec3d look = player.getRotationVec(1.0F).normalize();
        double minAngle = Double.MAX_VALUE;
        LivingEntity best = null;

        Box searchBox = player.getBoundingBox().expand(RANGE);
        for (LivingEntity candidate : client.world.getEntitiesByClass(
            LivingEntity.class, searchBox, entity -> isValidTarget(player, entity))) {

            Vec3d targetPos = candidate.getBoundingBox().getCenter();
            Vec3d delta = targetPos.subtract(eyePos);
            double distanceSquared = delta.lengthSquared();
            if (distanceSquared > RANGE_SQUARED || distanceSquared < 1.0E-6) {
                continue;
            }

            double dot = Math.max(-1.0, Math.min(1.0, look.dot(delta.normalize())));
            double angle = Math.toDegrees(Math.acos(dot));
            if (angle > FOV_DEGREES / 2.0) {
                continue;
            }

            if (angle < minAngle) {
                minAngle = angle;
                best = candidate;
            }
        }
        return best;
    }

    private static boolean isValidTarget(PlayerEntity player, LivingEntity entity) {
        return entity != player
            && entity.isAlive()
            && !entity.isSpectator()
            && !entity.isInvulnerable()
            && !(entity instanceof PlayerEntity other && (other.isCreative() || other.isSpectator()));
    }
}
