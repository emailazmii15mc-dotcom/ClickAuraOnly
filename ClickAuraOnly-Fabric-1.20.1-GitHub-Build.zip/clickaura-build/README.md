# ClickAura Only — Fabric 1.20.1

## Controls
- Press **Z** to toggle ClickAura ON/OFF.
- When enabled, hold left-click to attack a valid living target within 5 blocks.
- Respects Minecraft's normal attack cooldown.

## Build on GitHub (phone-friendly)
1. Create a new **public** repository on GitHub.
2. Upload all files and folders from this project, including the `.github/workflows/build.yml` file.
3. Open the repository's **Actions** tab.
4. Select **Build ClickAura Only**, then press **Run workflow**.
5. When the run finishes, open it and download the artifact named `ClickAuraOnly-Fabric-1.20.1`.
6. Extract the artifact ZIP. The `.jar` file is inside.

## Local build
Requires JDK 17 and Gradle 8.6:
```bash
gradle build
```
